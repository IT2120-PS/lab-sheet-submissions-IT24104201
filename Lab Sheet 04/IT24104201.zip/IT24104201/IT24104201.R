branch_data <- read.table("Exercise.txt",header=TRUE, sep = ",")
fix(branch_data)
attach(branch_data)

head(branch_data)

## Box plot for Sales_X1
boxplot(branch_data$Sales_X1,
        main = "Box plot for Sales",
        horizontal = TRUE
        )

# getting five number summary
summary(branch_data$Advertising_X2)

# Obtaining IQR of outlines of a data set
IQR(branch_data$Advertising_X2)

## Function to get outliers of a data set
find_outliers <- function(x) {
  
  #calculate the Q1 and Q3
  q1 <- quantile (x, 0.25)
  q3 <- quantile (x, 0.75)
  
  #calculate the IQR
  iqr <- q3 - q1
  
  #calculate the lower and upper bounds for outliers
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  
  #find the values that are below the lb or above the ub
  outliers <- x[x < lb | x > ub]
  
  return (outliers)
}
find_outliers(branch_data$Years_X3)
  

